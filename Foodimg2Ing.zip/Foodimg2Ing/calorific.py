# Sample calorie database (per 100g)
CALORIE_DB  =  {
    # Grains & Cereals
    "rice (white)": 130,
    "rice (brown)": 111,
    "wheat flour (whole wheat)": 340,
    "oats": 389,
    "maize/corn": 96,
    "barley": 123,
    "millet": 119,
    "breadcrumbs (plain, dry)": 395,

    # Bread & Bakery
    "white bread": 265,
    "whole wheat bread": 247,
    "bun (regular, plain)": 270,
    "roti (whole wheat)": 297,
    "pasta (plain)": 131,
    "biscuits (sweet)": 450,

    # Meat & Poultry
    "chicken (skinless, boneless)": 165,
    "chicken": 239,
    "beef (lean)": 250,
    "beef": 275,
    "mutton": 294,
    "pork": 242,
    "fish (salmon)": 206,
    "egg (whole)": 155,

    # Dairy Products
    "milk (whole, 3.25% fat)": 61,
    "milk (skimmed, 0.1% fat)": 34,
    "cheese (cheddar)": 402,
    "cheese (mozzarella)": 280,
    "yogurt (whole, plain)": 61,
    "butter": 717,
    "ghee (clarified butter)": 900,

    # Vegetables
    "potato (boiled, without skin)": 77,
    "sweet potato (boiled)": 86,
    "onion": 40,
    "tomato": 18,
    "carrot": 41,
    "lettuce": 15,
    "spinach": 23,
    "cabbage": 25,
    "broccoli": 34,
    "bell pepper (red)": 31,
    "cucumber (peeled)": 15,

    # Fruits
    "apple": 52,
    "banana": 89,
    "mango": 60,
    "grapes (red, seedless)": 69,
    "strawberry": 32,
    "pineapple": 50,
    "orange": 47,
    "watermelon": 30,

    # Nuts & Seeds
    "almonds": 579,
    "cashews": 553,
    "peanuts": 567,
    "walnuts": 654,
    "chia seeds": 486,
    "flax seeds": 534,
    "sunflower seeds": 584,

    # Spices & Condiments
    "salt": 0,
    "sugar": 387,
    "honey": 304,
    "black pepper": 251,
    "clove": 274,
    "cinnamon": 247,
    "coriander": 298,
    "cumin": 375,
    "turmeric": 312,
    "ginger": 80,
    "garlic": 149,
    "curry powder": 325,
    "masala (mixed spices)": 325,

    # Oils & Fats
    "vegetable oil": 884,
    "olive oil": 884,
    "coconut oil": 862,
    "butter": 717,
    "ghee": 900,

    # Snacks & Fast Food
    "french fries": 312,
    "burger (regular with bun & patty)": 295,
    "pizza (cheese, regular crust)": 266,
    "chocolate (dark, 70-85% cocoa)": 600,
    "ice cream (vanilla)": 207
}





def estimate_calories(ingredients, ingredient_weights=None):
    """
    Estimates the caloric value of a dish based on the predicted ingredients.
    
    Parameters:
    - ingredients (list): List of ingredient names predicted by the model.
    - ingredient_weights (dict, optional): Custom weights (grams) for each ingredient. If not provided, assumes 100g.

    Returns:
    - float: Estimated total calories of the dish.
    """
    total_calories = 0.0
    
    # Default weight is 100g per ingredient if no weights provided
    if ingredient_weights is None:
        ingredient_weights = {ing: 100 for ing in ingredients}

    for ing in ingredients:
        weight = ingredient_weights.get(ing, 100)  # Get weight (default 100g)
        cal_per_100g = CALORIE_DB.get(ing.lower(), 0)  # Get calorie value per 100g
        
        total_calories += (cal_per_100g * weight) / 100  # Adjust for actual weight

    return round(total_calories, 2)

# Example usage
#predicted_ingredients = ["chicken", "onion", "garlic", "butter"]
#ingredient_weights = {"chicken": 200, "onion": 50, "garlic": 10, "butter": 20}  # Custom weights in grams

#calories = estimate_calories(predicted_ingredients, ingredient_weights)
#return (f"Estimated Calories: {calories} kcal")
