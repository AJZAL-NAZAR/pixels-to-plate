
from Foodimg2Ing.calorific import estimate_calories
from flask import render_template ,url_for,flash,redirect,request,session
from Foodimg2Ing import app
from Foodimg2Ing.output import output
import os



app.secret_key = os.getenv('SECRET_KEY', 'fallback_key_if_missing')


@app.route('/',methods=['GET'])
def index():
    if 'username' in session: 
        return render_template('home.html')
    else:
        return redirect(url_for('login'))

@app.route('/home',methods=['GET'])
def home():
    if 'username' in session: 
        return render_template('home.html')
    else:
        return redirect(url_for('login'))

@app.route('/login',methods=['GET'])
def login():
    return render_template('login.html')

@app.route('/set_session')
def set_session():
    session['username'] = 'JohnDoe'
    session['logged_in'] = True
    return redirect(url_for('home'))


@app.route('/submit_form', methods=['GET', 'POST'])
def submit_form():
    if request.method == 'POST':
        uname = request.form.get('uname')
        pwd = request.form.get('pwd')
        if uname=="admin" and pwd=="admin":
            session['username'] = 'JohnDoe'
            session['logged_in'] = True
            return redirect(url_for('home'))
        else:
            return '''<script>alert("Invalid Credentials! Going back..."); window.history.back(); </script>'''
  
    
    return '''
        <form method="post">
            Name: <input type="text" name="name"><br>
            Email: <input type="email" name="email"><br>
            <input type="submit" value="Submit">
        </form>
    '''



@app.route('/about',methods=['GET'])
def about():
    return render_template('about.html')

@app.route('/',methods=['POST','GET'])
def predict():
    imagefile=request.files['imagefile']
    image_path=os.path.join(app.root_path,'static\\images\\demo_imgs',imagefile.filename)
    imagefile.save(image_path)
    img="/images/demo_imgs/"+imagefile.filename
    title,ingredients,recipe = output(image_path)
    calories=[]
    for i in ingredients:
        print(i)
        calories.append( estimate_calories(i)) 
    print(calories)
  
    return render_template('predict.html',title=title,ingredients=ingredients,recipe=recipe,img=img,calories=calories)

@app.route('/<samplefoodname>')
def predictsample(samplefoodname):
    imagefile=os.path.join(app.root_path,'static\\images',str(samplefoodname)+".jpg")
    img="/images/"+str(samplefoodname)+".jpg"
    title,ingredients,recipe = output(imagefile)
    print(ingredients)
    calories=[]
    for i in ingredients:
        print(i)
        calories.append( estimate_calories(i)) 
    print(calories)
    return render_template('predict.html',title=title,ingredients=ingredients,recipe=recipe,img=img,calories=calories)

@app.route('/logout')
def logout():
    session.pop('username', None)  # Remove 'username' key if it exists
    return render_template('logout.html')